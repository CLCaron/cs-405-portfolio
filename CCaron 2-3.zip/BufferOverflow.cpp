// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>

int main()
{
	std::cout << "Buffer Overflow Example" << std::endl;
	const std::string account_number = "CharlieBrown42";

	// Changed user_input to use std::string instead of char with a hard limit allowed
	std::string user_input;
	std::cout << "Enter a value: ";
	std::cin >> user_input;

	// Check that input is not over 20 characters
	if (user_input.length() > 20) {
		std::cout << "You entered more than 20 characters.";
	}
	else {
		std::cout << "You entered: " << user_input << std::endl;
		std::cout << "Account Number = " << account_number << std::endl;
	}

	
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
