// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Verify that we can add to an empty vector
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    add_entries(1);

    // We only add one entry and we already have a test to make sure that a collection is empty on create,
    // so test will fail if collection size is not 1
    ASSERT_EQ(collection->size(), 1);
}

// Verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    
    add_entries(5);

    // Like CanAddToEmptyVector, we check that the collection size is equal to the amount of entries from add_entries
    ASSERT_EQ(collection->size(), 5);
}

// Verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, VerifyMaxSize) {

    // Collections start at size 0, so no need to add entry for this check. 
    // ASSERT_GE checks if the first param is greater than or equal to the second param
    ASSERT_GE(collection->max_size(), collection->size());
    
    // Add one entry for a total of (1) entry in the collection
    add_entries(1);
    ASSERT_GE(collection->max_size(), collection->size());

    // Add four entries for a total of (5) entries in the collection
    add_entries(4);
    ASSERT_GE(collection->max_size(), collection->size());

    // Add five entries for a total of (10) entries in the collection
    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());
}

// Verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, VerifyCapacity) {

    // Check for 0 entries
    ASSERT_GE(collection->capacity(), collection->size());

    // Add one entry for a total of (1) entry in the collection
    add_entries(1);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add four entries for a total of (5) entries in the collection
    add_entries(4);
    ASSERT_GE(collection->capacity(), collection->size());

    // Add five entries for a total of (10) entries in the collection
    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());

}

// Verify resizing increases the collection
TEST_F(CollectionTest, VerifyResizeIncrease) {

    // Add entries so we can store a size other than 0 for comparison
    add_entries(4);

    // Store original collection size for comparison
    int originalCollectionSize = collection->size();

    // Increase collection size
    collection->resize(collection->size() + 1);

    // Check that the new collection size is greater than the original size (4)
    ASSERT_GT(collection->size(), originalCollectionSize);
}

// Verify resizing decreases the collection
TEST_F(CollectionTest, VerifyResizeDecrease) {

    // Add entries so we can store a size other than 0 for comparison
    add_entries(4);

    // Store original collection size for comparison
    int originalCollectionSize = collection->size();

    // Decrease collection size
    collection->resize(collection->size() - 1);

    //Check that the new collection size is less than the original size (4)
    ASSERT_LT(collection->size(), originalCollectionSize);
}

// Verify resizing decreases the collection to zero
TEST_F(CollectionTest, VerifyResizeToZero) {

    // Add entries so we can verify a decrease to 0 later
    add_entries(4);

    // Resize collection to 0
    collection->resize(0);

    // Check that collection size is 0
    ASSERT_EQ(collection->size(), 0);
}

// Verify clear erases the collection
TEST_F(CollectionTest, VerifyClear) {

    add_entries(5);

    collection->clear();

    ASSERT_EQ(collection->size(), 0);
}

// Verify erase(begin,end) erases the collection
TEST_F(CollectionTest, VerifyErase) {
    
    add_entries(5);
    
    // Erase elements in the collection from beginning to end 
    collection->erase(collection->begin(), collection->end());

    ASSERT_EQ(collection->size(), 0);
}

// Verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, VerifyReserve) {

    int originalCollectionCapacity = collection->capacity();
    int originalCollectionSize = collection->size();

    // Reserve a capacity greater than the current capacity
    collection->reserve(collection->capacity() + 10);

    // Verify that the collection capcity increased
    ASSERT_GT(collection->capacity(), originalCollectionCapacity);

    // Verify that the collection size has not changed
    ASSERT_EQ(collection->size(), originalCollectionSize);
}

// Verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, VerifyOutOfRangeException) {
    
    add_entries(5);
    EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Verify that popback will properly remove the last element in the collection
TEST_F(CollectionTest, VerifyPopBack) {

    // Assign 5 ints with a value of 50 to the collection
    collection->assign(5, 50);

    // Add a new element that is not 50
    collection->push_back(10);

    // Verify that the last element is 10
    ASSERT_EQ(collection->at(collection->size() - 1), 10);

    // Delete the last element
    collection->pop_back();

    //Verify that the last element is now 50
    ASSERT_EQ(collection->at(collection->size() - 1), 50);
}

TEST_F(CollectionTest, VerifyMaxSizeIncreaseException) {

    // Verify that an exception is thrown if a resize greater than the max size is attempted
    EXPECT_ANY_THROW(collection->resize(collection->max_size() + 1));
}
